=== Emi Loan Calculator ===
Contributors: piyushmca
Donate link: https://profiles.wordpress.org/piyushmca/
Tags: Loan Calculator, Mortgage Calculator, Simplify Mortgage Calculation, Finance Calculator, Home Loan Calculator, Real Estate Calculator, Calculator, Affordability Loan Calculator
Requires at least: 3.8
Requires PHP: 7.4
Tested up to: 6.2.2
Stable tag: 1.2
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 
Free All Loan Calculator for your Site - Home Loan - Car Loan - Credit Card Car Insurance - Mortgage Calculator - Shortcode [Loan-calculator]

== Description ==

Free All Loan Calculator for your Site - Home Loan - Car Loan - Credit Card Car Insurance - Mortgage Calculator - Shortcode [Loan-calculator]

To use Loan Calculator on your site, please put shortcode **[Loan-calculator]** in any page. 

 
== Installation ==

1. Upload `emi-loan-calculator` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

To use Loan Calculator on your site, please put shortcode **[Loan-calculator]** in any page.
 

== Screenshots ==

1. Loan Calculator Demo Shortcode [Loan-calculator]

== Changelog ==
= 1.2 =
* Fixed: New Updated Version.

= 1.1 =
* Fixed: languages add.

= 1.0 =
* ganerate simple Loan Calculator
* Emi search engine readable

== Upgrade Notice ==
= 1.1 = 
ganerate simple Emi Loan Calculator languages add..

= 1.0 = 
ganerate simple Emi Loan Calculator.

== Arbitrary section 1 ==

This Version is 1.1 Emi Loan Calculator